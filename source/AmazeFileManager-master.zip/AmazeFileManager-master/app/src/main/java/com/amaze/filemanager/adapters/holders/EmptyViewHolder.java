package com.amaze.filemanager.adapters.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Check RecyclerAdapter's doc.
 *
 * @author Emmanuel
 *         on 29/5/2017, at 22:48.
 */

public class EmptyViewHolder extends RecyclerView.ViewHolder {
    public EmptyViewHolder(View view) {
        super(view);
    }
}