package com.amaze.filemanager.utils;

/**
 * @author Emmanuel Messulam <emmanuelbendavid@gmail.com>
 *         on 8/12/2017, at 16:33.
 */

public class GlideConstants {

    public static final int MAX_PRELOAD_FILES = 50;
    public static final int MAX_PRELOAD_APPSADAPTER = 100;

}
