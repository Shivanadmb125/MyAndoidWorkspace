# WellPaper
WellPaper is a simple Android app to show awesome photos from [Flickr REST API](https://www.flickr.com/services/api/). App was inspired a lot from [Mike Penz](https://github.com/mikepenz)'s [Wallsplash](https://github.com/mikepenz/wallsplash-android/) which uses Unsplash and other platforms as image source.

#Download
<a href="https://play.google.com/store/apps/details?id=tr.mht.wallpaper&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-AC-global-none-all-co-pr-py-PartBadges-Oct1515-1"><img alt="Get it on Google Play" src="https://play.google.com/intl/en_us/badges/images/apps/en-play-badge-border.png" height="75" /></a>
