package jwtc.chess.board;

// ChessBoard. object extended from BoardMembers, BoardStatics and BoardConstants in order to split up some code and
// make things structured
//TODO some methods can be made protected because they are only used internally in this object
public class ChessBoard extends BoardMembers
{

	
	public ChessBoard()
	{
		
	}
	
	
	
	
}
